import dlt
from pyspark.sql.functions import *
from pyspark.sql.types import *

@dlt.table(
    name="bronze_customer_ingestion_cleaned"
)
# @dlt.expect_or_fail("valid_customer_id", "customer_id IS NOT NULL")
# @dlt.expect_or_drop("valid_customer_name", "name IS NOT NULL")
# @dlt.expect_or_drop("valid_dob", "dob IS NOT NULL")
# @dlt.expect_or_drop("valid_city", "city IS NOT NULL")
# @dlt.expect_or_drop("valid_join_date", "join_date IS NOT NULL")
# @dlt.expect_or_drop(
#     "valid_email",
#     "email IS NOT NULL AND email RLIKE '^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\\.[a-zA-Z0-9-.]+$'"
# )
# @dlt.expect_or_drop("valid_phone", "phone_number IS NOT NULL")
# @dlt.expect_or_drop("valid_channel", "preferred_channel IS NOT NULL")
# @dlt.expect_or_drop("valid_occupation", "occupation IS NOT NULL")
# @dlt.expect_or_drop("valid_income", "income_range IS NOT NULL")
# @dlt.expect_or_drop("valid_risksegment", "risk_segment IS NOT NULL")
# @dlt.expect_or_drop("valid_country", "country IS NOT NULL")
# @dlt.expect("valid_gender", "gender IS NOT NULL")
# @dlt.expect("valid_status", "status IS NOT NULL")

def bronze_customer_ingestion_cleaned():

    
       df= dlt.read_stream("landing_customer_incremental")
       df=df.withColumn("name",upper(col("name")))
       df=df.withColumn("email",lower(col("email"))) 
       df= df.withColumn("occupation",upper(col("occupation")))
       df= df.withColumn("city",upper(col("city")))
       df= df.withColumn("income_range",upper(col("income_range")))
       df= df.withColumn("risk_segment",upper(col("risk_segment")))
       df= df.withColumn("preferred_channel",upper(col("preferred_channel")))
  
       df= df.withColumn("gender", when(col("gender")=="M","MALE").when(col("gender")=="F","Female").otherwise("Unknown"))
       df= df.withColumn("status", when(col("status").isNull() | (trim(col("status")) == ""), lit("UNKNOWN")).otherwise(col("status")))
       df=df.withColumn("phone_number", trim(col("phone_number")))
       df=df.withColumn("phone_number",regexp_replace(col("phone_number"),"[^0-9]",""))
       df=df.filter(col("phone_number").rlike(r"^44\d{10}$"))
       df= df.withColumn("dob",to_date(col("dob"),"MM-dd-yyyy"))
       df=df.filter(col("preferred_channel").isin("ONLINE","MOBILE","BRANCH","ATM"))
       df=df.filter(col("income_range").isin("HIGH","MEDIUM","LOW"))
       df=df.filter(col("risk_segment").isin("HIGH","MEDIUM","LOW","UNKNOWN"))



       return df
   


@dlt.table(
    name="bronze_account_transactions_ingestion_cleaned"
)

 
@dlt.expect_or_drop("valid_account_id",  "account_id IS NOT NULL")
@dlt.expect_or_drop("valid_customer_id", "customer_id IS NOT NULL")
@dlt.expect_or_drop("valid_txn_id",      "txn_id IS NOT NULL")
@dlt.expect_or_drop("valid_account_type","account_type IS NOT NULL")
@dlt.expect_or_drop("valid_balance",     "balance IS NOT NULL")
@dlt.expect_or_drop("valid_txn_date",    "txn_date IS NOT NULL")      # fixed: was transaction_date
@dlt.expect_or_drop("valid_txn_amount",  "txn_amount IS NOT NULL")    # fixed: was transaction_amount
@dlt.expect_or_drop("valid_txn_type",    "txn_type IS NOT NULL")      # fixed: was transaction_type
@dlt.expect_or_drop("valid_txn_channel", "txn_channel IS NOT NULL")   # fixed: was transaction_channel
def bronze_account_transactions_ingestion_cleaned():
    df = dlt.read_stream("landing_account_tarsactions_incremental")  # fixed: typo "tarsactions"
    df = df.withColumn("account_type", upper(col("account_type")))
    df = df.withColumn("txn_channel",  upper(col("txn_channel")))
    df = df.withColumn("txn_type",     upper(col("txn_type")))
    df = df.withColumn("txn_type",
        when(col("txn_type") == "DEBITT",  "DEBIT")
        .when(col("txn_type") == "CREDIIT", "CREDIT")
        .otherwise(col("txn_type"))
    )
    return df