import dlt
from pyspark.sql.functions import *
from pyspark.sql.types import *

customer_schema = StructType([
    StructField("customer_id", IntegerType(), True),
    StructField("name", StringType(), True),
    StructField("dob", DateType(), True),
    StructField("gender", StringType(), True),
    StructField("city", StringType(), True),
    StructField("join_date", DateType(), True),
    StructField("status", StringType(), True),
    StructField("email", StringType(), True),
    StructField("phone_number", StringType(), True),
    StructField("preferred_channel", StringType(), True),
    StructField("occupation", StringType(), True),
    StructField("income_range", StringType(), True),
    StructField("risk_segment", StringType(), True),
    StructField("country", StringType(), True)
])

@dlt.table(
    name="landing_customer_incremental",
    comment="landing_customer_incremental data"
)
def landing_customer_incremental():
    return (
        spark.readStream
            .format("cloudFiles")
            .option("cloudFiles.format", "csv")
            .option("cloudFiles.includeExistingFiles", "true")
            .option("header", "true")
            .schema(customer_schema)
            .load("/Volumes/dlt_bank_project_catalog/dlt_bank_project_schema/dlt_bank_project_volume/cutomers/")
    )

account_schema=StructType([
    StructField("account_id", LongType(), True),
    StructField("customer_id", LongType(), True),
    StructField("account_type", StringType(), True),
    StructField("balance", DoubleType(), True),
    StructField("txn_id", LongType(), True),
    StructField("txn_date", DateType(), True),
    StructField("txn_type", StringType(), True),
    StructField("txn_amount", DoubleType(), True),
    StructField("txn_channel", StringType(), True) 
])

@dlt.table(
    name="landing_account_tarsactions_incremental",
    comment="landing_account_tarsactions_incremental data"
)
def landing_account_tarsactions_incremental():
    return (
        spark.readStream
            .format("cloudFiles")
            .option("cloudFiles.format", "csv")
            .option("cloudFiles.includeExistingFiles", "true")
            .option("header", "true")
            .schema(account_schema)
            .load("/Volumes/dlt_bank_project_catalog/dlt_bank_project_schema/dlt_bank_project_volume/accounts/")
    )
# @dlt.table(
#     name="bronze_customer",
#     comment ="bronze_customer data"
# )
# def bronze_customer():
#     return dlt.read_stream("landing_customer_incremental")