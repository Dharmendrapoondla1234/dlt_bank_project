import dlt
from pyspark.sql.functions import *
from pyspark.sql.types import *


##################### Datat tranformation for the customers table  ###################
@dlt.table(
    name="silver_cutomers_transformed",
    comment="This table contains the customers data"
   
)
def silver_cutomers_transformed():
   
    df=spark.readStream.table("bronze_customer_ingestion_cleaned")
    df=df.withColumn("customer_age",when(col("dob").isNotNull(),floor(months_between(current_date(),col("dob"))/12)).otherwise(lit(None)))
    df=df.withColumn("tenure_days",when(col("join_date").isNotNull(),datediff(current_date(),col("join_date"))).otherwise(lit(None)))
    df = df.withColumn("dob_out_of_range_flag",
    (col("dob") < to_date(lit("1900-01-01"))) | (col("dob") > current_date()))
    df=df.withColumn("transformatio_date",current_timestamp())
    return df

###########################appLY SCD 1 USING APPLY CHAGES ###########################
dlt.create_streaming_table("silver_customers_transformed_scd1")
dlt.apply_changes(
    target="silver_customers_transformed_scd1",
    source="silver_cutomers_transformed",
    keys=["customer_id"],
    sequence_by="transformatio_date",
    stored_as_scd_type=1,
    except_column_list=["transformatio_date"]
     
)

####################### data transfromation- transaction tabkle ###############################
@dlt.table(
    name="silver_account_transactions_transformed",
    comment="This table contains the transactions data"
)
def silver_account_transactions_transformed():
    df=spark.readStream.table("bronze_account_transactions_ingestion_cleaned")
    df = df.withColumn("channel_type",
    when(col("txn_channel") == "ATM", lit("PHYSICAL"))
    .when(col("txn_channel") == "BRANCH", lit("PHYSICAL"))
    .otherwise(lit("DIGITAL")))
    df=df.withColumn("txn_year",year(col("txn_date")))
    df=df.withColumn("txn_month",month(col("txn_date")))
    df=df.withColumn("txn_day",dayofmonth(col("txn_date")))
    df=df.withColumn("txn_direction",when(col("txn_type") == "DEBIT", lit("OUT")).otherwise(lit("IN")))
    df=df.withColumn("acc_transformation_date",current_timestamp())

    return df


######################################scd2 auto cdc#######################
dlt.create_streaming_table("silver_account_transactions_transformed_scd2")

 

dlt.apply_changes(
    target="silver_account_transactions_transformed_scd2",
    source="silver_account_transactions_transformed",
    keys=["txn_id"],
    sequence_by="acc_transformation_date",
    except_column_list=["acc_transformation_date"],
    stored_as_scd_type=2
)
# DBTITLE 1,"

@dlt.view(
    name="silver_customer_transformed__view",
    comment="This view contains the transactions data"
)
def silver_customer_transformed__view():
    return spark.readStream.table("silver_cutomers_transformed")



@dlt.view(
    name="silver_account_transactions_transformed__view",
    comment="This view contains the transactions data"
)
def silver_account_transactions_transformed__view():
    return spark.readStream.table("silver_account_transactions_transformed")

  
     