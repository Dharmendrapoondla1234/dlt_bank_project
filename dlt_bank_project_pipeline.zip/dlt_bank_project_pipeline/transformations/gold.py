import dlt
from pyspark.sql.functions import *
from pyspark.sql.types import *
@dlt.table(
    name="gold_cus_acc_tranc_mv"
)


def gold_cus_acc_tranc_mv():
   customers=dlt.read("silver_cutomers_transformed")
   tx=dlt.read("silver_account_transactions_transformed")

    
   joined = customers.join(tx, "customer_id", "inner")
   return joined

#################### AGRREAGATIONS #####################

@dlt.table(
    name="gold_cus_acc_tranc_agg"
)
   
def gold_cus_acc_tranc_agg():
   df=dlt.read("gold_cus_acc_tranc_mv")
   return ((df.groupBy("customer_id","name","city","status","income_range","risk_segment","customer_age","tenure_days")
             .agg(countDistinct("account_id").alias("total_accounts"),
                  count("*").alias("txt_count"),
                  sum(when(col("txn_type") == "CREDIT", col("txn_amount")).otherwise(lit(0.0))).alias("total_credit"),  # fixed: lt()->lit(), moved .alias() outside sum()
                  sum(when(col("txn_type") == "DEBIT",  col("txn_amount")).otherwise(lit(0.0))).alias("total_debit"),   # fixed: otherwise(0)->otherwise(lit(0.0))
                  avg("txn_amount").alias("avg_txn_amount"),
                  min("txn_date").alias("first_txn_date"),
                  max("txn_date").alias("last_txn_date"),
                  countDistinct("txn_channel").alias("channels_used") )
    ))



















